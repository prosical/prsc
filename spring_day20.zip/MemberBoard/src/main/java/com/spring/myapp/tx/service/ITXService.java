package com.spring.myapp.tx.service;

public interface ITXService {

	void insertTx(String str);
}
