package com.spring.myapp.aop.service;

public interface IHelloService {
	
	String sayHello(String name);
	String sayGoodBye(String name);

}
